#!/bin/bash

rm -rf jniLibs

ndk-build

for p in arm64-v8a; do
	mv libs/$p/{tun2socks,libtun2socks.so}
	mv libs/$p/{pdnsd,libpdnsd.so}
done

mv libs jniLibs
