# Third-party notices

- **SocksDroid**: original project by PeterCxy, maintained fork by bndeff. See `LICENSE` in this repository.
- **Xray-core**: Copyright Project X contributors, Mozilla Public License 2.0 (MPL-2.0). Source: https://github.com/XTLS/Xray-core . The build workflow pins Android ARM64 release `v26.11.9` and verifies the release archive SHA-256 before packaging. The corresponding Xray license text is included in the APK assets.
- **badvpn/tun2socks**, **pdnsd**, and **libancillary** retain their upstream license and notice files in `app/src/main/jni/`.
