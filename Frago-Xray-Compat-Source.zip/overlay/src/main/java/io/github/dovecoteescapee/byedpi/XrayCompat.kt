package io.github.dovecoteescapee.byedpi

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/** Converts the supported parts of a V2Ray/Xray-style JSON into Frago's native ByeDPI schema.
 * This is a compatibility importer, not an Xray runtime.
 */
object XrayCompat {
    data class Result(val config: JSONObject, val warnings: List<String>)

    fun convert(source: JSONObject): Result {
        val inbounds = source.optJSONArray("inbounds") ?: throw JSONException("آرایه inbounds پیدا نشد")
        val outbounds = source.optJSONArray("outbounds") ?: throw JSONException("آرایه outbounds پیدا نشد")
        val socks = (0 until inbounds.length()).asSequence()
            .mapNotNull { inbounds.optJSONObject(it) }
            .firstOrNull { it.optString("protocol").equals("socks", true) }
            ?: throw JSONException("ورودی SOCKS در inbounds پیدا نشد")

        val listen = socks.optString("listen", "127.0.0.1")
        if (listen != "127.0.0.1" && listen != "localhost") {
            throw JSONException("Frago فقط SOCKS محلی 127.0.0.1 را پشتیبانی می‌کند")
        }
        val port = socks.optInt("port", 1080)
        if (port !in 1024..65535) throw JSONException("پورت SOCKS نامعتبر است")

        val fragmentOutbound = (0 until outbounds.length()).asSequence()
            .mapNotNull { outbounds.optJSONObject(it) }
            .firstOrNull { it.optString("tag") == "fragment-out" }
        val fragmentSettings = fragmentOutbound?.optJSONObject("settings")?.optJSONObject("fragment")
        val packetMode = fragmentSettings?.optString("packets", "tlshello") ?: "tlshello"
        if (!packetMode.equals("tlshello", true)) {
            throw JSONException("در این نسخه فقط packets=tlshello قابل تبدیل است")
        }

        // ByeDPI has no Xray-style randomized fragment length/interval pair.
        // Split at SNI and split the TLS record at SNI as the closest supported behavior.
        val args = JSONArray().put("--split").put("1+s").put("--tlsrec").put("1+s")
        val dns = findNumericDns(source.optJSONObject("dns")) ?: "1.1.1.1"
        val dnsServers = source.optJSONObject("dns")?.optJSONArray("servers")
        val doh = dnsServers?.let { array ->
            (0 until array.length()).map { array.optString(it) }.firstOrNull { it.startsWith("https://") }
        }

        val warnings = mutableListOf<String>()
        if (doh != null) warnings += "DNS رمزگذاری‌شده DoH در این نسخه اجرا نمی‌شود؛ DNS محلی $dns جایگزین شده است."
        if (fragmentSettings?.optString("length")?.isNotBlank() == true || fragmentSettings?.optString("interval")?.isNotBlank() == true) {
            warnings += "length و interval در ByeDPI معادل مستقیم ندارند؛ TLS با split و tlsrec در محل SNI قطعه‌بندی می‌شود، نه با همان بازه تصادفی Xray."
        }
        if (source.optJSONObject("dns")?.optJSONObject("hosts")?.length()?.let { it > 0 } == true) {
            warnings += "قوانین dns.hosts و regexp در این تبدیل اعمال نمی‌شوند."
        }
        if (source.optJSONObject("routing")?.optJSONArray("rules")?.length()?.let { it > 0 } == true) {
            warnings += "قوانین routing از جمله دامنه‌های .ir، IPهای خصوصی و outboundهای direct/block در موتور فعلی قابل اجرا نیستند؛ ترافیک فقط بر اساس برنامه‌های انتخاب‌شده هدایت می‌شود."
        }
        if (outbounds.length() > 1) {
            warnings += "چند outbound در Xray به یک موتور محلی ByeDPI تبدیل نمی‌شوند؛ فقط fragment-out برای ترافیک TCP انتخاب‌شده استفاده می‌شود."
        }

        val native = JSONObject()
            .put("version", 1)
            .put("apps", JSONArray())
            .put("dns", dns)
            .put("ipv6", false)
            .put("socks_port", port)
            .put("fragment", JSONObject().put("args", args))
            .put("compatibility", JSONObject()
                .put("source", "xray-json")
                .put("original_doh", doh ?: JSONObject.NULL)
                .put("original_fragment_length", fragmentSettings?.optString("length") ?: JSONObject.NULL)
                .put("original_fragment_interval", fragmentSettings?.optString("interval") ?: JSONObject.NULL)
                .put("warnings", JSONArray(warnings)))
        return Result(native, warnings)
    }

    fun normalize(config: JSONObject): Result {
        if (config.has("inbounds") || config.has("outbounds")) return convert(config)
        val copy = JSONObject(config.toString())
        if (!copy.has("version")) copy.put("version", 1)
        if (!copy.has("apps")) copy.put("apps", JSONArray())
        if (!copy.has("dns")) copy.put("dns", "1.1.1.1")
        if (!copy.has("ipv6")) copy.put("ipv6", false)
        if (!copy.has("socks_port")) copy.put("socks_port", 1080)
        return Result(copy, emptyList())
    }

    private fun findNumericDns(dns: JSONObject?): String? {
        val servers = dns?.optJSONArray("servers") ?: return null
        for (i in 0 until servers.length()) {
            val value = servers.optString(i).trim()
            if (value.matches(Regex("^(?:[0-9]{1,3}\\.){3}[0-9]{1,3}$"))) return value
        }
        return null
    }
}
