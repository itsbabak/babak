package io.github.dovecoteescapee.byedpi.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import io.github.dovecoteescapee.byedpi.FragoActivity
import io.github.dovecoteescapee.byedpi.R
import io.github.dovecoteescapee.byedpi.core.ByeDpiProxy
import io.github.dovecoteescapee.byedpi.core.ByeDpiProxyCmdPreferences
import io.github.dovecoteescapee.byedpi.core.TProxyService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket

class FragoVpnService : VpnService() {
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var proxy = ByeDpiProxy()
    private var proxyJob: Job? = null
    private var tunFd: ParcelFileDescriptor? = null
    private var isStopping = false
    private var configFile: File? = null

    companion object {
        private const val TAG = "FragoVpnService"
        private const val CHANNEL_ID = "frago_vpn"
        private const val NOTIFICATION_ID = 731
        private const val ACTION_START = "io.frago.android.action.START"
        private const val ACTION_STOP = "io.frago.android.action.STOP"
        private const val PREFS = "frago_preferences"
        private const val KEY_CONFIG = "config_json"
        private const val DEFAULT_SOCKS_PORT = 1080
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                startForegroundCompat()
                serviceScope.launch { startTunnel() }
                return START_STICKY
            }
            ACTION_STOP -> {
                serviceScope.launch { stopTunnel() }
                return START_NOT_STICKY
            }
            else -> return START_NOT_STICKY
        }
    }

    override fun onRevoke() {
        serviceScope.launch { stopTunnel() }
        super.onRevoke()
    }

    private fun startForegroundCompat() {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, FragoActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_frago)
                .setContentTitle("Frago")
                .setContentText("Fragment is active for selected apps")
                .setContentIntent(openIntent)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .build()
        } else {
            buildLegacyNotification(openIntent)
        }
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private suspend fun startTunnel() {
        if (tunFd != null) return
        try {
            isStopping = false
            val config = readConfig()
            val selectedApps = readApps(config)
            require(selectedApps.isNotEmpty()) { "No apps selected" }
            val socksPort = config.optInt("socks_port", DEFAULT_SOCKS_PORT)
            require(socksPort in 1024..65535) { "Invalid local SOCKS port" }

            // Start the local ByeDPI SOCKS5 engine. It does not connect to a remote VPN server.
            proxy = ByeDpiProxy()
            val args = mutableListOf("ciadpi", "--ip", "127.0.0.1", "--port", socksPort.toString())
            val customArgs = config.optJSONObject("fragment")?.optJSONArray("args")
            if (customArgs != null) {
                for (i in 0 until customArgs.length()) {
                    val value = customArgs.optString(i)
                    require(value.isNotBlank()) { "Empty fragment argument" }
                    require(value !in listOf("-i", "--ip", "-p", "--port", "-D", "--daemon", "-w", "--pidfile")) {
                        "Argument $value is managed by Frago"
                    }
                    args += value
                }
            }
            val enginePreferences = ByeDpiProxyCmdPreferences(args.toTypedArray())
            proxyJob = serviceScope.launch {
                val result = proxy.startProxy(enginePreferences)
                if (!isStopping) {
                    Log.e(TAG, "ByeDPI exited with code $result")
                    serviceScope.launch { stopTunnel() }
                }
            }

            waitForProxy(socksPort)

            val builder = Builder()
                .setSession("Frago")
                .addAddress("10.10.10.10", 32)
                .addRoute("0.0.0.0", 0)

            val dns = config.optString("dns", "1.1.1.1")
            builder.addDnsServer(dns)
            if (config.optBoolean("ipv6", false)) {
                builder.addAddress("fd00::1", 128)
                    .addRoute("::", 0)
            }

            var added = 0
            for (packageName in selectedApps) {
                try {
                    if (isPackageInstalled(packageName)) {
                        builder.addAllowedApplication(packageName)
                        added++
                    }
                } catch (_: Exception) {
                    Log.w(TAG, "Skipping missing or unavailable app: $packageName")
                }
            }
            require(added > 0) { "No selected apps are installed" }

            val fd = builder.establish() ?: error("Android did not establish the VPN interface")
            tunFd = fd
            configFile = File(cacheDir, "frago-tunnel.yml").apply { writeText(tunnelConfig(socksPort)) }
            TProxyService.TProxyStartService(configFile!!.absolutePath, fd.fd)
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean("running", true)
                .remove("last_error")
                .apply()
            Log.i(TAG, "Frago tunnel started for $added selected apps")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start tunnel", e)
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString("last_error", e.message ?: "Tunnel start failed")
                .putBoolean("running", false)
                .apply()
            stopTunnel()
        }
    }

    private suspend fun waitForProxy(socksPort: Int) {
        repeat(30) {
            if (isStopping) error("Connection cancelled")
            try {
                Socket().use { it.connect(InetSocketAddress("127.0.0.1", socksPort), 250) }
                return
            } catch (_: Exception) {
                delay(150)
            }
        }
        error("Local fragmentation proxy did not start")
    }

    private suspend fun stopTunnel() {
        if (isStopping) return
        isStopping = true
        try {
            runCatching { TProxyService.TProxyStopService() }
            runCatching { tunFd?.close() }
            tunFd = null
            configFile?.delete()
            configFile = null
            withContext(Dispatchers.IO) {
                runCatching { proxy.stopProxy() }
            }
            proxyJob?.join()
            proxyJob = null
        } catch (e: Exception) {
            Log.w(TAG, "Error while stopping", e)
        } finally {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("running", false).apply()
            removeForegroundNotification()
            stopSelf()
        }
    }

    private fun readConfig(): JSONObject {
        val raw = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_CONFIG, null)
            ?: error("No Frago configuration saved")
        val config = JSONObject(raw)
        val apps = config.optJSONArray("apps") ?: error("Config has no apps array")
        require(apps.length() > 0) { "Select at least one app in Frago" }
        return config
    }

    private fun readApps(config: JSONObject): List<String> {
        val array = config.optJSONArray("apps") ?: return emptyList()
        return (0 until array.length()).map { array.getString(it) }.filter { it.isNotBlank() && it != applicationContext.packageName }
    }

    private fun tunnelConfig(socksPort: Int): String = """
        misc:
          task-stack-size: 81920
        socks5:
          mtu: 8500
          address: 127.0.0.1
          port: $socksPort
          udp: udp
    """.trimIndent()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Frago connection", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Local Fragment tunnel status"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    @Suppress("DEPRECATION")
    private fun buildLegacyNotification(openIntent: PendingIntent): Notification =
        Notification.Builder(this)
            .setSmallIcon(R.drawable.ic_stat_frago)
            .setContentTitle("Frago")
            .setContentText("Fragment is active for selected apps")
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()

    @Suppress("DEPRECATION")
    private fun removeForegroundNotification() {
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
    }

    @Suppress("DEPRECATION")
    private fun isPackageInstalled(packageName: String): Boolean = try {
        packageManager.getPackageInfo(packageName, 0)
        true
    } catch (_: Exception) {
        false
    }

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }
}
