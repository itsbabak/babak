package io.github.dovecoteescapee.byedpi

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale

class FragoActivity : Activity() {
    private lateinit var editor: EditText
    private lateinit var statusView: TextView

    companion object {
        private const val REQUEST_VPN = 4201
        private const val REQUEST_OPEN_JSON = 4202
        private const val REQUEST_SAVE_JSON = 4203
        private const val PREFS = "frago_preferences"
        private const val KEY_CONFIG = "config_json"
        private const val ACTION_START = "io.frago.android.action.START"
        private const val ACTION_STOP = "io.frago.android.action.STOP"

        private val DEFAULT_CONFIG = """{
  "version": 1,
  "apps": [],
  "dns": "1.1.1.1",
  "ipv6": false,
  "socks_port": 1080,
  "fragment": {
    "args": ["--split", "1+s", "--tlsrec", "1+s"]
  }
}"""
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        val saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_CONFIG, null)
        editor.setText(saved ?: DEFAULT_CONFIG)
        refreshSelectedCount()
    }

    override fun onResume() {
        super.onResume()
        if (::editor.isInitialized) refreshSelectedCount()
    }

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(20))
            setBackgroundColor(Color.rgb(7, 13, 30))
        }

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(page)
        }

        val title = TextView(this).apply {
            text = "Frago"
            textSize = 30f
            setTextColor(Color.rgb(238, 248, 255))
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        page.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "Fragment control · سبک، محلی و بدون Xray"
            textSize = 13f
            setTextColor(Color.rgb(134, 165, 190))
            setPadding(0, dp(4), 0, dp(18))
        }
        page.addView(subtitle, matchWrap())

        statusView = TextView(this).apply {
            text = "وضعیت: آماده"
            textSize = 14f
            setTextColor(Color.rgb(47, 224, 206))
            background = rounded(Color.rgb(13, 39, 55), dp(14))
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        page.addView(statusView, matchWrap())

        addSectionTitle(page, "برنامه‌های هدف")
        addButton(page, "انتخاب برنامه‌هایی که از فرگمنت استفاده کنند", true) { showAppPicker() }

        addSectionTitle(page, "فایل تنظیمات JSON")
        val help = TextView(this).apply {
            text = "می‌توانی JSON با ساختار Xray را وارد یا اینجا جای‌گذاری کنی؛ Frago بخش‌های قابل پشتیبانی را به تنظیمات داخلی ByeDPI تبدیل می‌کند. این برنامه Xray یا sing-box اجرا نمی‌کند."
            textSize = 12f
            setTextColor(Color.rgb(151, 173, 194))
            setPadding(0, 0, 0, dp(10))
        }
        page.addView(help, matchWrap())

        editor = EditText(this).apply {
            setTextColor(Color.rgb(226, 242, 255))
            setHintTextColor(Color.rgb(110, 132, 154))
            setHint("JSON configuration")
            textSize = 13f
            typeface = Typeface.MONOSPACE
            gravity = Gravity.TOP or Gravity.START
            setPadding(dp(12), dp(12), dp(12), dp(12))
            minLines = 10
            maxLines = 18
            isVerticalScrollBarEnabled = true
            setHorizontallyScrolling(false)
            background = rounded(Color.rgb(14, 25, 45), dp(12), Color.rgb(37, 70, 101))
        }
        page.addView(editor, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(240)))

        val fileRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 2f
        }
        fileRow.addView(makeButton("وارد کردن JSON") { openJsonFile() }, weightedButtonParams())
        fileRow.addView(makeButton("خروجی JSON") { exportJsonFile() }, weightedButtonParams())
        page.addView(fileRow, matchWrap())

        addSectionTitle(page, "اتصال")
        addButton(page, "ذخیره تنظیمات و اتصال", true) { requestConnect() }
        addButton(page, "قطع اتصال", false) { stopVpn() }

        val foot = TextView(this).apply {
            text = "Frago آدرس IP را تغییر نمی‌دهد و سرور واسطه ندارد. نتیجه به نوع فیلترینگ و پارامتر انتخابی بستگی دارد."
            textSize = 11f
            setTextColor(Color.rgb(118, 143, 166))
            setPadding(0, dp(18), 0, 0)
        }
        page.addView(foot, matchWrap())
        setContentView(scroll)
    }

    private fun addSectionTitle(parent: LinearLayout, text: String) {
        val label = TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(Color.rgb(220, 240, 255))
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(20), 0, dp(8))
        }
        parent.addView(label, matchWrap())
    }

    private fun addButton(parent: LinearLayout, text: String, primary: Boolean, action: () -> Unit) {
        parent.addView(makeButton(text, primary, action), matchWrap().also { it.topMargin = dp(7) })
    }

    private fun makeButton(text: String, primary: Boolean = false, action: () -> Unit): Button {
        return Button(this).apply {
            this.text = text
            isAllCaps = false
            textSize = 14f
            setTextColor(if (primary) Color.rgb(5, 25, 39) else Color.rgb(215, 237, 255))
            background = rounded(
                if (primary) Color.rgb(44, 220, 213) else Color.rgb(21, 42, 66),
                dp(12),
                if (primary) Color.TRANSPARENT else Color.rgb(47, 83, 115)
            )
            setOnClickListener { action() }
        }
    }

    private fun showAppPicker() {
        val pm = packageManager
        val apps = try {
            pm.getInstalledApplications(0)
                .filter { it.packageName != packageName && pm.getLaunchIntentForPackage(it.packageName) != null }
                .map { AppEntry(it.packageName, it.loadLabel(pm)?.toString() ?: it.packageName) }
                .sortedBy { it.label.lowercase(Locale.ROOT) }
        } catch (e: Exception) {
            Toast.makeText(this, "فهرست برنامه‌ها قابل دریافت نیست: ${e.message}", Toast.LENGTH_LONG).show()
            return
        }
        if (apps.isEmpty()) {
            Toast.makeText(this, "برنامه‌ای برای انتخاب پیدا نشد", Toast.LENGTH_SHORT).show()
            return
        }

        val current = try { XrayCompat.normalize(parseConfig(editor.text.toString())).config.getJSONArray("apps").toStringSet() }
        catch (_: Exception) { emptySet() }
        val labels = apps.map { "${it.label}\n${it.packageName}" }.toTypedArray()
        val checked = BooleanArray(apps.size) { apps[it].packageName in current }

        AlertDialog.Builder(this)
            .setTitle("برنامه‌های تحت فرگمنت")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("اعمال انتخاب") { _, _ ->
                val selected = JSONArray()
                apps.forEachIndexed { index, entry -> if (checked[index]) selected.put(entry.packageName) }
                try {
                    val config = XrayCompat.normalize(parseConfig(editor.text.toString())).config
                    config.put("apps", selected)
                    editor.setText(config.toString(2))
                    persistConfig(config)
                    refreshSelectedCount()
                } catch (e: Exception) {
                    Toast.makeText(this, "ابتدا JSON را اصلاح کن: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun refreshSelectedCount() {
        val count = try { XrayCompat.normalize(parseConfig(editor.text.toString())).config.getJSONArray("apps").length() } catch (_: Exception) { 0 }
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val running = prefs.getBoolean("running", false)
        val error = prefs.getString("last_error", null)
        statusView.text = when {
            running -> "وضعیت: متصل  ·  $count برنامه انتخاب شده"
            !error.isNullOrBlank() -> "خطا: $error"
            else -> "وضعیت: آماده  ·  $count برنامه انتخاب شده"
        }
    }

    private fun requestConnect() {
        val converted = try {
            XrayCompat.normalize(parseConfig(editor.text.toString()))
        } catch (e: Exception) {
            Toast.makeText(this, "تبدیل JSON ناموفق بود: ${e.message}", Toast.LENGTH_LONG).show()
            return
        }
        val config = converted.config
        try { validateConfig(config) } catch (e: Exception) {
            Toast.makeText(this, "تنظیمات معتبر نیست: ${e.message}", Toast.LENGTH_LONG).show()
            return
        }
        editor.setText(config.toString(2))
        persistConfig(config)
        showCompatibilityWarnings(converted.warnings)
        val permissionIntent = VpnService.prepare(this)
        if (permissionIntent != null) {
            startActivityForResult(permissionIntent, REQUEST_VPN)
        } else {
            startFragoService(ACTION_START)
        }
    }

    private fun stopVpn() {
        startService(Intent(this, FragoVpnService::class.java).setAction(ACTION_STOP))
        statusView.text = "وضعیت: در حال قطع اتصال"
    }

    private fun startFragoService(action: String) {
        val intent = Intent(this, FragoVpnService::class.java).setAction(action)
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        statusView.text = if (action == ACTION_START) "وضعیت: در حال اتصال" else "وضعیت: در حال قطع اتصال"
    }

    private fun openJsonFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
        }
        startActivityForResult(intent, REQUEST_OPEN_JSON)
    }

    private fun exportJsonFile() {
        try {
            val config = parseConfig(editor.text.toString())
            validateConfig(config)
            persistConfig(config)
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/json"
                putExtra(Intent.EXTRA_TITLE, "frago-config.json")
            }
            startActivityForResult(intent, REQUEST_SAVE_JSON)
        } catch (e: Exception) {
            Toast.makeText(this, "JSON معتبر نیست: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Activity result API retained for compatibility with the upstream minimum SDK")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        when (requestCode) {
            REQUEST_VPN -> startFragoService(ACTION_START)
            REQUEST_OPEN_JSON -> {
                val uri = data?.data ?: return
                try {
                    contentResolver.openInputStream(uri)?.use { input ->
                        val content = BufferedReader(InputStreamReader(input)).readText()
                        val converted = XrayCompat.normalize(parseConfig(content))
                        val config = converted.config
                        validateConfig(config, requireApps = false)
                        editor.setText(config.toString(2))
                        persistConfig(config)
                        refreshSelectedCount()
                        showCompatibilityWarnings(converted.warnings)
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "خواندن فایل ناموفق بود: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
            REQUEST_SAVE_JSON -> {
                val uri = data?.data ?: return
                try {
                    contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(editor.text.toString()) }
                    Toast.makeText(this, "فایل JSON ذخیره شد", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "ذخیره فایل ناموفق بود: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun parseConfig(raw: String): JSONObject = JSONObject(raw)

    private fun validateConfig(config: JSONObject, requireApps: Boolean = true) {
        val apps = config.optJSONArray("apps") ?: JSONArray()
        if (requireApps && apps.length() == 0) throw JSONException("حداقل یک برنامه را انتخاب کن")
        for (i in 0 until apps.length()) {
            val pkg = apps.optString(i)
            if (pkg.isBlank() || pkg == packageName) throw JSONException("نام بسته برنامه نامعتبر است")
        }
        val fragment = config.optJSONObject("fragment") ?: JSONObject()
        val args = fragment.optJSONArray("args") ?: JSONArray()
        if (args.length() > 30) throw JSONException("تعداد پارامترهای fragment زیاد است")
        for (i in 0 until args.length()) {
            val arg = args.optString(i)
            if (arg.isBlank()) throw JSONException("پارامتر خالی مجاز نیست")
            if (arg in listOf("-i", "--ip", "-p", "--port", "-D", "--daemon", "-w", "--pidfile")) {
                throw JSONException("پارامتر $arg توسط خود برنامه مدیریت می‌شود")
            }
        }
        val dns = config.optString("dns", "1.1.1.1")
        if (dns.isBlank() || !dns.matches(Regex("^(?:[0-9]{1,3}\\.){3}[0-9]{1,3}$"))) throw JSONException("DNS باید یک IPv4 معتبر باشد")
        val port = config.optInt("socks_port", 1080)
        if (port !in 1024..65535) throw JSONException("پورت SOCKS نامعتبر است")
    }

    private fun showCompatibilityWarnings(warnings: List<String>) {
        if (warnings.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle("تبدیل انجام شد؛ محدودیت‌ها")
            .setMessage(warnings.joinToString("\n\n", prefix = "• "))
            .setPositiveButton("متوجه شدم", null)
            .show()
    }

    private fun persistConfig(config: JSONObject) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_CONFIG, config.toString()).apply()
    }

    private fun JSONArray.toStringSet(): Set<String> = buildSet {
        for (i in 0 until length()) add(optString(i))
    }

    private data class AppEntry(val packageName: String, val label: String)

    private fun rounded(color: Int, radius: Int, stroke: Int = Color.TRANSPARENT): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun weightedButtonParams() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
        marginStart = dp(3); marginEnd = dp(3); topMargin = dp(7)
    }
}
