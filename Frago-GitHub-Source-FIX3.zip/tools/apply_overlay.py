#!/usr/bin/env python3
"""Apply the Frago UI/service overlay to the pinned ByeDPIAndroid checkout."""
from __future__ import annotations
import re
import shutil
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ANDROID = "http://schemas.android.com/apk/res/android"
ET.register_namespace("android", ANDROID)
ET.register_namespace("tools", "http://schemas.android.com/tools")

def a(name: str) -> str:
    return f"{{{ANDROID}}}{name}"

def copy_overlay(upstream: Path) -> None:
    src = ROOT / "overlay" / "src" / "main"
    dst = upstream / "app" / "src" / "main"
    for rel in ["java/io/github/dovecoteescapee/byedpi/FragoActivity.kt",
                "java/io/github/dovecoteescapee/byedpi/services/FragoVpnService.kt",
                "res/drawable/ic_stat_frago.xml",
                "res/values/colors_frago.xml",
                "res/mipmap-mdpi/ic_launcher.png",
                "res/mipmap-hdpi/ic_launcher.png",
                "res/mipmap-xhdpi/ic_launcher.png",
                "res/mipmap-xxhdpi/ic_launcher.png",
                "res/mipmap-xxxhdpi/ic_launcher.png",
                "res/mipmap-mdpi/ic_launcher_round.png",
                "res/mipmap-hdpi/ic_launcher_round.png",
                "res/mipmap-xhdpi/ic_launcher_round.png",
                "res/mipmap-xxhdpi/ic_launcher_round.png",
                "res/mipmap-xxxhdpi/ic_launcher_round.png",
                "res/drawable-nodpi/frago_foreground.png",
                "res/mipmap-anydpi-v26/ic_launcher.xml",
                "res/mipmap-anydpi-v26/ic_launcher_round.xml"]:
        target = dst / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src / rel, target)


def patch_manifest(path: Path) -> None:
    tree = ET.parse(path)
    root = tree.getroot()
    # Query installed launchable apps for the per-app picker. This is a sideloaded utility,
    # not a Play Store-distributed app.
    if not any(el.tag == "uses-permission" and el.get(a("name")) == "android.permission.QUERY_ALL_PACKAGES" for el in root):
        permission = ET.Element("uses-permission", {a("name"): "android.permission.QUERY_ALL_PACKAGES"})
        app_index = next((i for i, el in enumerate(list(root)) if el.tag == "application"), len(root))
        root.insert(app_index, permission)

    app = root.find("application")
    if app is None:
        raise RuntimeError("AndroidManifest.xml has no <application>")

    # The upstream screens and proxy service are not part of Frago's minimal UI.
    # Remove their manifest entries so Android exposes only Frago's VPN service.
    for activity in list(app.findall("activity")):
        if activity.get(a("name")) in (".activities.MainActivity", ".activities.SettingsActivity"):
            app.remove(activity)
    for service_entry in list(app.findall("service")):
        if service_entry.get(a("name")) in (
            ".services.ByeDpiVpnService", ".services.ByeDpiProxyService", ".services.QuickTileService"
        ):
            app.remove(service_entry)

    if not any(x.tag == "activity" and x.get(a("name")) == "io.github.dovecoteescapee.byedpi.FragoActivity" for x in app):
        activity = ET.SubElement(app, "activity", {
            a("name"): "io.github.dovecoteescapee.byedpi.FragoActivity",
            a("exported"): "true",
            a("configChanges"): "keyboardHidden|orientation|screenSize"
        })
        filt = ET.SubElement(activity, "intent-filter")
        ET.SubElement(filt, "action", {a("name"): "android.intent.action.MAIN"})
        ET.SubElement(filt, "category", {a("name"): "android.intent.category.LAUNCHER"})

    if not any(x.tag == "service" and x.get(a("name")) == "io.github.dovecoteescapee.byedpi.services.FragoVpnService" for x in app):
        service = ET.SubElement(app, "service", {
            a("name"): "io.github.dovecoteescapee.byedpi.services.FragoVpnService",
            a("permission"): "android.permission.BIND_VPN_SERVICE",
            a("foregroundServiceType"): "specialUse",
            a("exported"): "false"
        })
        filt = ET.SubElement(service, "intent-filter")
        ET.SubElement(filt, "action", {a("name"): "android.net.VpnService"})
        ET.SubElement(service, "meta-data", {
            a("name"): "android.net.VpnService.SUPPORTS_ALWAYS_ON",
            a("value"): "false"
        })
        ET.SubElement(service, "property", {
            a("name"): "android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE",
            a("value"): "vpn"
        })

    tree.write(path, encoding="utf-8", xml_declaration=True)


def patch_strings(resource_root: Path) -> None:
    changed = 0
    for path in resource_root.rglob("strings.xml"):
        text = path.read_text(encoding="utf-8")
        updated, n = re.subn(r'(<string\s+name="app_name"\s*>).*?(</string>)', r'\1Frago\2', text, count=1, flags=re.S)
        if n:
            path.write_text(updated, encoding="utf-8")
            changed += 1
    if changed == 0:
        raise RuntimeError("Could not find app_name string in app resources")


def patch_gradle(path: Path) -> None:
    text = path.read_text(encoding="utf-8")
    # Small arm64-only APK for Samsung A36/A56 class devices.
    text = re.sub(r'^\s*abiFilters\.add\("(?:armeabi-v7a|arm64-v8a|x86|x86_64)"\)\s*$', '', text, flags=re.M)
    marker = 'ndk {\n'
    if marker not in text:
        raise RuntimeError("Could not find ndk block in app/build.gradle.kts")
    text = text.replace(marker, marker + '            abiFilters.add("arm64-v8a")\n', 1)
    text = text.replace('applicationId = "io.github.dovecoteescapee.byedpi"', 'applicationId = "io.frago.android"')
    text = text.replace('compileSdk = 34', 'compileSdk = 34\n    ndkVersion = "26.3.11579264"')
    text = text.replace('versionName = "1.2.0"', 'versionName = "1.0.0"')
    path.write_text(text, encoding="utf-8")
    app_mk = path.parent / "src/main/jni/Application.mk"
    if app_mk.exists():
        mk_text = app_mk.read_text(encoding="utf-8")
        mk_text = re.sub(r'^APP_ABI\s*:=.*$', 'APP_ABI := arm64-v8a', mk_text, flags=re.M)
        app_mk.write_text(mk_text, encoding="utf-8")


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: apply_overlay.py PATH_TO_BYEDPIANDROID_CHECKOUT", file=sys.stderr)
        return 2
    upstream = Path(sys.argv[1]).resolve()
    if not (upstream / "app" / "src" / "main" / "AndroidManifest.xml").is_file():
        raise SystemExit(f"Not a ByeDPIAndroid checkout: {upstream}")
    copy_overlay(upstream)
    patch_manifest(upstream / "app/src/main/AndroidManifest.xml")
    patch_strings(upstream / "app/src/main/res")
    patch_gradle(upstream / "app/build.gradle.kts")
    print("Frago overlay applied.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
