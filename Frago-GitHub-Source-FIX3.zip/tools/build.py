#!/usr/bin/env python3
from __future__ import annotations
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / ".build" / "upstream"

def run(cmd: list[str], cwd: Path | None = None) -> None:
    print("+", " ".join(cmd), flush=True)
    subprocess.run(cmd, cwd=cwd, check=True)

def main() -> None:
    BUILD.parent.mkdir(parents=True, exist_ok=True)
    if not BUILD.exists():
        run(["git", "clone", "--depth", "1", "--branch", "v1.2.0",
             "https://github.com/dovecoteescapee/ByeDPIAndroid.git", str(BUILD)])
    run(["git", "submodule", "update", "--init", "--recursive"], cwd=BUILD)
    run(["python3", str(ROOT / "tools" / "apply_overlay.py"), str(BUILD)])
    gradlew = BUILD / "gradlew"
    gradlew.chmod(gradlew.stat().st_mode | 0o111)
    run(["./gradlew", "--no-daemon", "clean", "assembleDebug"], cwd=BUILD)
    out = ROOT / "artifacts"
    out.mkdir(exist_ok=True)
    shutil.copy2(BUILD / "app/build/outputs/apk/debug/app-debug.apk", out / "Frago-arm64-debug.apk")
    print(f"APK ready: {out / 'Frago-arm64-debug.apk'}")

if __name__ == "__main__":
    main()
