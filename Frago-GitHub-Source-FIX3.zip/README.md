# Frago — Android Fragment client

Frago is a minimal Android front-end for a **local DPI-desynchronization/fragmentation engine**. It does not use Xray-core or sing-box. It uses the open-source ByeDPI native core as the local SOCKS5 engine and `hev-socks5-tunnel` to connect Android's per-app VPN interface to that local proxy.

## What it does

- Lets you choose exactly which installed apps use the local fragmentation path.
- Other apps are not added to the VPN allow-list and continue using Android's normal network route.
- Lets you edit the Frago JSON configuration inside the app.
- Imports and exports that JSON file.
- Offers the native ByeDPI command-line options as a JSON `fragment.args` array.
- Builds an **arm64-v8a** APK for modern Samsung phones (including Galaxy A36/A56).

> Important: Frago is a local DPI-desynchronization tool, not a remote VPN. It does not change your public IP, encrypt traffic to a remote server, or make every blocked destination reachable. It only helps against filtering methods that can be affected by the selected desynchronization/fragmentation technique. The JSON format below is Frago's own format; it is **not** an Xray/V2Ray/sing-box JSON file and cannot run VLESS/VMess/Trojan/Reality server profiles.

## JSON format

```json
{
  "version": 1,
  "apps": [
    "com.android.chrome",
    "org.telegram.messenger"
  ],
  "dns": "1.1.1.1",
  "ipv6": false,
  "fragment": {
    "args": ["--split", "1+s"]
  }
}
```

`apps` is a list of Android package names. The in-app app picker fills this list for you. At least one app must be selected before connecting. `fragment.args` is passed to the ByeDPI native core. Examples of supported options include `--split`, `--disorder`, `--fake`, `--tlsrec`, `--hosts`, `--proto`, and `--auto`; see the upstream ByeDPI README for the exact option syntax. Do not set the local listen address/port (`--ip`, `--port`) or daemon/pid-file flags in this field; Frago owns those values.

## Build APK using GitHub Actions

1. Create a new empty GitHub repository.
2. Extract the ZIP on your computer, then upload **every file and folder inside the extracted folder** to the repository root (not just `build.yml`, and not the ZIP itself). Keep `.github`, `tools`, and `overlay` at the root. Before running Actions, the repository must contain `tools/apply_overlay.py` and `overlay/src/main/`.
3. Open the **Actions** tab and enable workflows if GitHub asks.
4. Run **Build Frago APK** manually, or push a commit to `main`.
5. Open the completed workflow run and download the `Frago-arm64-debug-apk` artifact.

The workflow uses `android-actions/setup-android@v4` (the older v3 action requests the discontinued Android SDK `tools` package and fails with `Failed to find package 'tools'`). It fetches the upstream Android build project and its native source submodules during the build. That keeps this ZIP small while still producing the actual native app. A network connection is therefore required during the GitHub Actions build.

## Local build

The same build can be run locally on Linux with JDK 17, Android SDK, NDK 26.3, CMake 3.22.1, Python 3, and Git:

```bash
python3 tools/build.py
```

## Credits and licenses

Frago's overlay is a minimal rebrand/configuration front-end. Native functionality is supplied by these upstream projects, fetched at build time:

- [ByeDPIAndroid](https://github.com/dovecoteescapee/ByeDPIAndroid) — GPL-3.0
- [ByeDPI](https://github.com/hufrea/byedpi) — see the upstream repository license
- [hev-socks5-tunnel](https://github.com/heiher/hev-socks5-tunnel) — MIT

Their original notices and licenses are retained in the upstream checkout used by the build. Frago does not claim authorship of those native components.

## Importing an Xray-style JSON file

Frago can preserve and display an Xray-style JSON document and append its own `apps` list, but it does **not** execute Xray `inbounds`, `outbounds`, `routing`, `hosts`, or the Xray `freedom.settings.fragment` implementation. When such a file is detected, the app displays a confirmation before starting the local ByeDPI engine. If `fragment.args` is absent, Frago uses the default ByeDPI `--split 1+s` strategy.

Android's `VpnService.Builder.addDnsServer()` requires a numeric IP address. For a DNS object containing `https://dns.google/dns-query`, this build selects `8.8.8.8` as a plain-DNS compatibility fallback and displays a warning. This does **not** provide DoH encryption or implement Xray's DNS `hosts`/`queryStrategy` rules. For predictable behavior, use a numeric `dns` value such as `"dns": "8.8.8.8"`.

The `\/` sequences that may appear after editing are valid JSON escaping for `/`; they do not change the URL. The added top-level `apps` array is Frago's per-app VPN selection list.
