# Third-party components

Frago's GitHub Actions build downloads these projects at build time. Their own source files and license notices are retained in `.build/upstream` during the build.

- **ByeDPIAndroid** — GPL-3.0; Android VPN application integration. https://github.com/dovecoteescapee/ByeDPIAndroid
- **ByeDPI** — native local SOCKS5 desynchronization/fragmentation engine. https://github.com/hufrea/byedpi
- **hev-socks5-tunnel** — local TUN-to-SOCKS5 bridge; MIT. https://github.com/heiher/hev-socks5-tunnel

Frago's Android front-end and build overlay are distributed under GPL-3.0 to match the derivative application's licensing requirements. See `LICENSE`.
